print("kuku")
